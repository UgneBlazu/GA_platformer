package main;

import java.awt.Graphics;

import javax.imageio.ImageIO;

import entity.Player;
import levels.LevelManager;

public class Game implements Runnable {
	
	// import classes	
	private GamePanel gamePanel;
	private GameWindow gameWindow;

	private Thread gameThread;
	private Player player;
	private LevelManager levelManager;
	
	// fps & ups
	private final int FPS_SET = 120;
	private final int UPS_SET = 200;
	
	// tiles default size and scale
	public final static int DEFAULT_TILE_SIZE = 32; //32x32 tile
	public final static float SCALE = 1.5f;
	
	// tile dimensions 
	public final static int TILES_IN_WIDTH = 26; 
	public final static int TILES_IN_HEIGHT = 14;
	public final static int TILES_SIZE = (int)(DEFAULT_TILE_SIZE * SCALE); // 64x64
	public final static int GAME_WIDTH = TILES_SIZE * TILES_IN_WIDTH; // 1664 pixels
	public final static int GAME_HEIGHT = TILES_SIZE * TILES_IN_HEIGHT; // 1024 pixels	
		
	public Game() {
			initClasses();

			//creates the visible game window by initiating the gp and gw classes
			gamePanel = new GamePanel(this);
			gameWindow = new GameWindow(gamePanel);
			gamePanel.requestFocus();

			// starts the game loop
			startGameLoop();
		}
		
		// method used to initiate classes
		private void initClasses() {
			levelManager = new LevelManager(this);
			player = new Player(200, 200, (int) (64 * SCALE), (int) (40 * SCALE));
			player.loadLvlData(levelManager.getCurrentLevel().getLevelData());

		}

		// starts game loop
		private void startGameLoop() {
			gameThread = new Thread(this);
			gameThread.start();
		}

		public void update() {
			levelManager.update();
			player.update();
		}
		
		public void render(Graphics g) {
			
			levelManager.draw(g);
			player.render(g);
		}

		@Override
		public void run() {

			// used to calculate fps and ups
			double timePerFrame = 1000000000.0 / FPS_SET;
			double timePerUpdate = 1000000000.0 / UPS_SET;

			long previousTime = System.nanoTime();

			int frames = 0;
			int updates = 0;
			long lastCheck = System.currentTimeMillis();

			double deltaU = 0;
			double deltaF = 0;

			while (true) {
				long currentTime = System.nanoTime();

				deltaU += (currentTime - previousTime) / timePerUpdate;
				deltaF += (currentTime - previousTime) / timePerFrame;
				previousTime = currentTime;

				if (deltaU >= 1) {
					update();
					updates++;
					deltaU--;
				}

				if (deltaF >= 1) {
					gamePanel.repaint();
					frames++;
					deltaF--;
				}

				if (System.currentTimeMillis() - lastCheck >= 1000) {
					lastCheck = System.currentTimeMillis();
					System.out.println("FPS: " + frames + " | UPS: " + updates);
					frames = 0;
					updates = 0;

				}
			}

		}

		// when clicking out of the game window, inputs no longer register in the game
		public void windowFocusLost() {
			player.resetDirBooleans();
		}

		public Player getPlayer() {
			return player;
		}
}
