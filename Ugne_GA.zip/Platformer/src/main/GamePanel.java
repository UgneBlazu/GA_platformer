package main;

import static main.Game.*;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

import inputs.KeyboardInputs;

public class GamePanel extends JPanel{
	
	// imports classes
	private Game game;

	public GamePanel(Game game) {
		this.game = game;
		setPanelSize();
		addKeyListener(new KeyboardInputs(this));
	}

	// sets the games width and height
	private void setPanelSize() {
		Dimension size = new Dimension(GAME_WIDTH, GAME_HEIGHT);
		setPreferredSize(size);
	}

	public void updateGame() {

	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		game.render(g);
	}

	public Game getGame() {
		return game;
	}

}
